package PageBin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BookPageFactory {
	
	WebDriver driver;
	
	public BookPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name="userName")
	@CacheLookup
	WebElement username;

	@FindBy(name="userPwd")
	@CacheLookup
	WebElement password;

	@FindBy(name="mobile")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(name="loginbtn")
	@CacheLookup
	WebElement loginbtn;
	
	@FindBy(name="bookbtn")
	@CacheLookup
	WebElement bookbtn;
	
	
	@FindBy(id="userErrMsg")
	@CacheLookup
	WebElement errmsg;

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String susername) {
		username.sendKeys(susername);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String spassword) {
		password.sendKeys(spassword);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String smobile) {
		mobile.sendKeys(smobile);
	}

	public WebElement getLoginbtn() {
		return loginbtn;
	}

	public void setLoginbtn() {
		loginbtn.click();
	}

	public WebElement getBookbtn() {
		return bookbtn;
	}

	public void setBookbtn() {
		bookbtn.click();
	}

	public String getErrmsg() {
		return errmsg.getText();
	}
	
}
