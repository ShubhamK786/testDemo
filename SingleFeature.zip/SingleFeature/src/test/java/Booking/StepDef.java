package Booking;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBin.BookPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	WebDriver driver;
	BookPageFactory obj;
	
	@Given("^launch the login page$")
	public void launch_the_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SKUMA643\\Desktop\\BDD\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj = new BookPageFactory(driver);
		driver.get("file:///C:/Users/SKUMA643/Desktop/BDD_HTML/login.html");
	}

	@When("^Clicks the login button$")
	public void clicks_the_login_button() throws Throwable {
		obj.setLoginbtn();
		Thread.sleep(500);
	}

	@Then("^Display alert message$")
	public void display_alert_message() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String alertMsg = alert.getText();
		Thread.sleep(500);
		System.out.println("****"+alertMsg+"****");
		alert.accept();
		driver.close();
	}

	@When("^Leaves the username blank and clicks login button$")
	public void leaves_the_username_blank_and_clicks_login_button() throws Throwable {
	    obj.setUsername("");
		Thread.sleep(500);
	    obj.setLoginbtn();
		Thread.sleep(500);
	}

	@Then("^Display error message$")
	public void display_error_message() throws Throwable {
		obj.getErrmsg();
		Thread.sleep(500);
	}

	@When("^Leaves the password blank and clicks login button$")
	public void leaves_the_password_blank_and_clicks_login_button() throws Throwable {
	    obj.setUsername("admin");
		Thread.sleep(500);
	    obj.setPassword("");
		Thread.sleep(500);
	    obj.setLoginbtn();
	    Thread.sleep(500);
	}

	@When("^Enter all valid data for login$")
	public void enter_all_valid_data_for_login() throws Throwable {
		obj.setUsername("admin");
		Thread.sleep(500);
	    obj.setPassword("root");
		Thread.sleep(500);
	    obj.setLoginbtn();
	    Thread.sleep(500);
	}

	@When("^Navigate to Booking Page$")
	public void navigate_to_Booking_Page() throws Throwable {
		driver.navigate().to("file:///C:/Users/SKUMA643/Desktop/BDD_HTML/book.html");
		Thread.sleep(500);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^Leaves the username blank and clicks booking button$")
	public void leaves_the_username_blank_and_clicks_booking_button() throws Throwable {
	    obj.setUsername("");
		Thread.sleep(500);
	    obj.setBookbtn();
	    Thread.sleep(500);
	}

	@When("^Clicks the booking button$")
	public void clicks_the_booking_button() throws Throwable {
	    obj.setBookbtn();
	    Thread.sleep(500);
	}

	@When("^Leaves the mobile blank and clicks booking button$")
	public void leaves_the_mobile_blank_and_clicks_booking_button() throws Throwable {
		obj.setUsername("admin");
		Thread.sleep(500);
		obj.setMobile("");
		Thread.sleep(500);
	    obj.setBookbtn();
	    Thread.sleep(500);
	}

	@When("^Enter all valid data for booking$")
	public void enter_all_valid_data_for_booking() throws Throwable {
		obj.setUsername("admin");
		Thread.sleep(500);
		obj.setMobile("7898988745");
		Thread.sleep(500);
	    obj.setBookbtn();
	    Thread.sleep(500);
	}

	@Then("^Navigate to Confirm Page$")
	public void navigate_to_Confirm_Page() throws Throwable {
		driver.navigate().to("file:///C:/Users/SKUMA643/Desktop/BDD_HTML/confirm.html");
		Thread.sleep(500);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}
}
